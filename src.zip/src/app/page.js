"use client";

import Link from "next/link";
import { useState, useEffect, useRef } from "react";
import FlashSale from "@/components/FlashSale";

// ─── Styles (inline vars, no extra config needed) ───────────────────────────
const S = {
  g:    "#0F6B40",
  gbg:  "#EBF5F0",
  gb:   "#BAD9CA",
  off:  "#F7F7F5",
  off2: "#F0EFEC",
  b:    "#E5E5E3",
  b2:   "#CECCC7",
  t:    "#111111",
  m:    "#6B6B67",
  s:    "#9B9B97",
  r:    "#C8392B",
  rbg:  "#FEF1F0",
  rb:   "#F5C0BE",
};

// ─── ProductCard ─────────────────────────────────────────────────────────────
const ProductCard = ({ item }) => (
  <Link
    href={item.link}
    className="group block rounded-2xl overflow-hidden border transition-all duration-200 bg-white"
    style={{ borderColor: S.b }}
    onMouseEnter={e => {
      e.currentTarget.style.borderColor = S.b2;
      e.currentTarget.style.transform = "translateY(-2px)";
    }}
    onMouseLeave={e => {
      e.currentTarget.style.borderColor = S.b;
      e.currentTarget.style.transform = "translateY(0)";
    }}
  >
    <div className="aspect-[4/3] relative overflow-hidden" style={{ background: S.off2 }}>
      <img
        src={item.image}
        alt={item.name}
        className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        onError={e => {
          e.target.src = `https://placehold.co/400x300/EBF5F0/0F6B40?text=${encodeURIComponent(item.name)}`;
        }}
      />
      {item.isHot && (
        <div
          className="absolute top-2 right-2 text-xs font-medium px-2 py-0.5 rounded-md"
          style={{ background: S.gbg, color: S.g, border: `1px solid ${S.gb}` }}
        >
          Populer
        </div>
      )}
    </div>
    <div className="px-3 py-2.5">
      <p className="text-sm font-medium truncate" style={{ color: S.t }}>{item.name}</p>
      <p className="text-xs mt-0.5 truncate" style={{ color: S.s }}>{item.publisher}</p>
    </div>
  </Link>
);

// ─── SectionHeader ───────────────────────────────────────────────────────────
const SectionHeader = ({ title, showAll, onShowAll }) => (
  <div className="flex items-baseline justify-between mb-5">
    <h2 className="text-base font-semibold" style={{ color: S.t, letterSpacing: "-0.2px" }}>
      {title}
    </h2>
    {showAll && (
      <button
        onClick={onShowAll}
        className="text-sm transition-colors"
        style={{ color: S.m }}
        onMouseEnter={e => e.target.style.color = S.t}
        onMouseLeave={e => e.target.style.color = S.m}
      >
        Lihat semua →
      </button>
    )}
  </div>
);

// ─── FAQ Item ────────────────────────────────────────────────────────────────
const FaqItem = ({ q, a, defaultOpen = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${S.b}` }}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-5 py-4 text-left transition-colors"
        style={{ background: open ? S.off : "#fff", color: S.t }}
      >
        <span className="text-sm font-medium pr-4">{q}</span>
        <svg
          className="flex-shrink-0 transition-transform duration-200"
          style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)", width: 16, height: 16 }}
          fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"
        >
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>
      {open && (
        <div
          className="px-5 pb-5 text-sm leading-relaxed"
          style={{ background: S.off, color: S.m, borderTop: `1px solid ${S.b}` }}
        >
          <div className="pt-4">{a}</div>
        </div>
      )}
    </div>
  );
};

// ─── Main Page ───────────────────────────────────────────────────────────────
export default function Home() {
  const [banners, setBanners]         = useState([]);
  const [currentBanner, setCurrentBanner] = useState(0);
  const [activeFilter, setActiveFilter]   = useState("all");
  const prodRef = useRef(null);

  // Fetch banners
  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const res  = await fetch("https://kayanamart.my.id/api/banners");
        const data = await res.json();
        if (data.status === "success") setBanners(data.data);
      } catch (err) {
        console.error("Gagal ambil banner:", err);
      }
    };
    fetchBanners();
  }, []);

  // Auto-slide banner
  useEffect(() => {
    if (banners.length <= 1) return;
    const id = setInterval(() => {
      setCurrentBanner(prev => (prev === banners.length - 1 ? 0 : prev + 1));
    }, 4000);
    return () => clearInterval(id);
  }, [banners.length]);

  // Filter categories
  const handleFilter = (id) => {
    setActiveFilter(id);
    // scroll ke section produk
    prodRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  // ── Data produk (sama persis dengan versi lama) ───────────────────────────
  const menuGames = [
    { name: "Mobile Legends",  publisher: "Moonton",       link: "/ml",           isHot: true,  image: "/images/ml.png" },
    { name: "Free Fire",       publisher: "Garena",        link: "/ff",           isHot: true,  image: "/images/ff.png" },
    { name: "Magic Chess",     publisher: "Moonton",       link: "/magic-chess",  isHot: false, image: "/images/mcgg.jpg" },
    { name: "Point Blank",     publisher: "Zepetto",       link: "/pb",           isHot: false, image: "/images/pb.jpg" },
    { name: "Arena of Valor",  publisher: "Garena",        link: "/aov",          isHot: false, image: "/images/aov.png" },
    { name: "Valorant",        publisher: "Riot Games",    link: "/valorant",     isHot: true,  image: "/images/valo.jpg" },
    { name: "PUBG Mobile",     publisher: "Tencent",       link: "/pubgm",        isHot: false, image: "/images/pubg.png" },
    { name: "Call of Duty",    publisher: "Garena",        link: "/codm",         isHot: false, image: "/images/cod.jpg" },
    { name: "Lords Mobile",    publisher: "IGG",           link: "/lords-mobile", isHot: false, image: "/images/lordmobile.png" },
    { name: "Genshin Impact",  publisher: "HoYoverse",     link: "/genshin",      isHot: true,  image: "/images/genshin.jpg" },
    { name: "Stumble Guys",    publisher: "Scopely",       link: "/stumble-guys", isHot: false, image: "/images/SG.png" },
    { name: "FC Mobile",       publisher: "EA Sports",     link: "/fc-mobile",    isHot: false, image: "/images/fcm.jpg" },
    { name: "Honor of Kings",  publisher: "Level Infinite",link: "/hok",          isHot: false, image: "/images/hok.png" },
    { name: "Blood Strike",    publisher: "NetEase",       link: "/blood-strike", isHot: false, image: "/images/bs.jpg" },
    { name: "Draconia Saga",   publisher: "Sugarfun",      link: "/draconia",     isHot: false, image: "/images/DS.png" },
    { name: "Delta Force",     publisher: "TiMi Studio",   link: "/delta-force",  isHot: false, image: "/images/DF.png" },
  ];

  const menuVoucher = [
    { name: "Google Play ID",  publisher: "Google",      link: "/google-play",    isHot: true,  image: "/images/gplay.png" },
    { name: "Garena",          publisher: "Garena",      link: "/garena-voucher", isHot: false, image: "/images/garena.jpg" },
    { name: "Steam Wallet",    publisher: "Valve",       link: "/steam",          isHot: false, image: "/images/STW.jpg" },
    { name: "Spotify",         publisher: "Spotify",     link: "/spotify",        isHot: false, image: "/images/spotify.png" },
    { name: "Vidio",           publisher: "Emtek Group", link: "/vidio",          isHot: false, image: "/images/vidio.png" },
    { name: "WeTV",            publisher: "Tencent",     link: "/wetv",           isHot: false, image: "/images/wetv.jpg" },
    { name: "e-Meterai",       publisher: "PERURI",      link: "/emeterai",       isHot: false, image: "/images/EM.png" },
    { name: "Viu",             publisher: "PCCW Media",  link: "/viu",            isHot: false, image: "/images/viu.png" },
  ];

  const menuPulsa = [
    { name: "Token PLN",   publisher: "PLN Group",         link: "/pln",       isHot: false, image: "/images/pln.jpg" },
    { name: "Telkomsel",   publisher: "Telkomsel",         link: "/telkomsel", isHot: true,  image: "/images/telkomsel.png" },
    { name: "Indosat",     publisher: "Indosat Ooredoo",   link: "/indosat",   isHot: false, image: "/images/indosat.jpg" },
    { name: "Axis",        publisher: "Axis Telekom",      link: "/axis",      isHot: false, image: "/images/axis.png" },
    { name: "Smartfren",   publisher: "Smartfren",         link: "/smartfren", isHot: false, image: "/images/smartfren.png" },
    { name: "Tri",         publisher: "Hutchison 3",       link: "/tri",       isHot: false, image: "/images/tri.jpg" },
    { name: "XL",          publisher: "XL Axiata",         link: "/xl",        isHot: false, image: "/images/XL.jpg" },
    { name: "by.U",        publisher: "Telkomsel",         link: "/byu",       isHot: false, image: "/images/by.u.png" },
  ];

  const menuTagihan = [
    { name: "BPJS Kesehatan",        publisher: "BPJS Kesehatan",      link: "/bpjs-kesehatan", isHot: true,  image: "/images/bpjs.jpg" },
    { name: "PDAM Daerah",           publisher: "Daerah",              link: "/pdam",           isHot: false, image: "/images/pdam.png" },
    { name: "Pajak PBB",             publisher: "Pajak Negara",        link: "/pbb",            isHot: false, image: "/images/pbb.jpeg" },
    { name: "BPJS Ketenagakerjaan",  publisher: "BPJS TK",            link: "/bpjs-tk",        isHot: false, image: "/images/bpjstk.jpg" },
  ];

  const menuEntertainment = [
    { name: "Spotify Premium",  publisher: "Spotify",     link: "/spotify",    isHot: true,  image: "/images/spotify.png" },
    { name: "Vidio",            publisher: "Emtek",       link: "/vidio",      isHot: false, image: "/images/vidio.png" },
    { name: "WeTV",             publisher: "Tencent",     link: "/wetv",       isHot: false, image: "/images/wetv.jpg" },
    { name: "Viu",              publisher: "PCCW Media",  link: "/viu",        isHot: false, image: "/images/viu.png" },
  ];

  // Shortcut layanan utama
  const featuredServices = [
    { ico: "⚡", name: "Token PLN",     sub: "Semua nominal",      link: "/pln" },
    { ico: "🏥", name: "BPJS Kesehatan", sub: "Bayar iuran mudah", link: "/bpjs-kesehatan" },
    { ico: "📱", name: "Pulsa & Data",   sub: "Semua operator",    link: "/telkomsel" },
    { ico: "💧", name: "PDAM",           sub: "Tagihan air",       link: "/pdam" },
  ];

  // Filter chip config
  const filters = [
    { id: "all",           label: "Semua" },
    { id: "games",         label: "🎮 Games" },
    { id: "voucher",       label: "🎟 Voucher" },
    { id: "pulsa",         label: "📱 Pulsa & Data" },
    { id: "tagihan",       label: "🧾 Tagihan" },
    { id: "entertainment", label: "🎬 Entertainment" },
  ];

  // Sections config — urutan Games duluan
  const sections = [
    { id: "games",         title: "🎮 Top Up Games",       data: menuGames },
    { id: "voucher",       title: "🎟 Voucher Digital",    data: menuVoucher },
    { id: "pulsa",         title: "📱 Pulsa, Data & PLN",  data: menuPulsa },
    { id: "tagihan",       title: "🧾 Bayar Tagihan",      data: menuTagihan },
    { id: "entertainment", title: "🎬 Entertainment",      data: menuEntertainment },
  ];

  const faqs = [
    {
      q: "Apa itu KayanaPay?",
      a: "KayanaPay adalah platform digital untuk top up game, isi pulsa, beli paket data, bayar tagihan listrik, air, BPJS, dan berbagai kebutuhan digital lainnya. Semua diproses otomatis dan tersedia 24 jam.",
    },
    {
      q: "Berapa lama proses transaksi?",
      a: "Hampir semua transaksi diproses secara instan dalam hitungan detik. Untuk beberapa produk tertentu bisa memakan waktu 1–5 menit. Jika lebih dari 10 menit, segera hubungi CS kami.",
    },
    {
      q: "Metode pembayaran apa saja yang tersedia?",
      a: "Kami menerima QRIS (gratis), e-wallet (OVO, DANA, ShopeePay, LinkAja), transfer bank via Virtual Account (BCA, BNI, Mandiri, BRI), dan pembayaran di minimarket (Indomaret & Alfamart).",
    },
    {
      q: "Apakah transaksi di KayanaPay aman?",
      a: "Ya, sangat aman. Sistem kami menggunakan enkripsi berlapis untuk melindungi data dan transaksimu. Kami tidak menyimpan informasi kartu atau rekening bank.",
    },
    {
      q: "Bagaimana jika top up tidak masuk ke akun?",
      a: "Jika transaksi berhasil dibayar tapi item belum masuk dalam 10 menit, silakan hubungi CS kami via WhatsApp dengan menyertakan nomor pesanan. Kami akan menyelesaikan dalam waktu singkat.",
    },
    {
      q: "Apakah ada biaya admin?",
      a: "QRIS tidak dikenakan biaya admin sama sekali. Biaya admin hanya berlaku untuk beberapa metode tertentu dan akan ditampilkan secara transparan sebelum kamu bayar.",
    },
  ];

  return (
    <main className="min-h-screen pb-20" style={{ background: S.off }}>

      {/* ── TRUST BAR ─────────────────────────────────────────────────────── */}
      <div className="hidden sm:block" style={{ background: S.g }}>
        <div className="max-w-5xl mx-auto px-4 py-2 flex justify-center gap-8 flex-wrap">
          {["✦ Proses otomatis 24 jam", "✦ Transaksi aman & terenkripsi", "✦ 50.000+ pengguna aktif"].map(t => (
            <span key={t} className="text-xs" style={{ color: "rgba(255,255,255,.85)" }}>{t}</span>
          ))}
        </div>
      </div>

      {/* ── HERO — Banner Slider ──────────────────────────────────────────── */}
      {banners.length > 0 && (
        <section className="bg-white" style={{ borderBottom: `1px solid ${S.b}` }}>
          <div className="max-w-5xl mx-auto px-4 py-8">
            <div
              className="relative rounded-2xl overflow-hidden aspect-[21/8] md:aspect-[3/1]"
              style={{ background: S.off2, border: `1px solid ${S.b}` }}
            >
              {banners.map((bn, i) => (
                <Link
                  key={bn.id}
                  href={bn.target_link || "#"}
                  className={`absolute inset-0 transition-opacity duration-1000 ${i === currentBanner ? "opacity-100 z-10" : "opacity-0 z-0"}`}
                >
                  <img
                    src={`https://kayanamart.my.id${bn.image_url}`}
                    alt={`Banner ${i + 1}`}
                    className="w-full h-full object-cover"
                  />
                </Link>
              ))}
              {banners.length > 1 && (
                <div className="absolute bottom-3 left-0 right-0 z-20 flex justify-center gap-1.5">
                  {banners.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentBanner(idx)}
                      className="rounded-full transition-all duration-300"
                      style={{
                        height: "6px",
                        width: idx === currentBanner ? "20px" : "6px",
                        background: idx === currentBanner ? S.g : "rgba(255,255,255,.6)",
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* ── HERO — Static fallback (tidak ada banner) ─────────────────────── */}
      {banners.length === 0 && (
        <section className="bg-white" style={{ borderBottom: `1px solid ${S.b}` }}>
          <div className="max-w-5xl mx-auto px-4 py-14 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              {/* Eyebrow */}
              <div
                className="inline-flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-full mb-5"
                style={{ background: S.gbg, color: S.g, border: `1px solid ${S.gb}` }}
              >
                <span className="w-1.5 h-1.5 rounded-full animate-pulse inline-block" style={{ background: S.g }}></span>
                Platform PPOB Terpercaya
              </div>
              <h1
                className="text-3xl font-bold leading-tight mb-4"
                style={{ color: S.t, letterSpacing: "-0.6px" }}
              >
                Top up, bayar, dan<br />beli semua digital<br />
                <span style={{ color: S.g }}>di satu tempat.</span>
              </h1>
              <p className="text-sm leading-relaxed mb-7" style={{ color: S.m }}>
                Game, pulsa, listrik, BPJS — semua bisa dilakukan siapa saja, kapan saja, proses instan.
              </p>
              <div className="flex gap-3">
                <Link
                  href="#produk"
                  className="text-sm font-medium px-5 py-2.5 rounded-xl text-white transition"
                  style={{ background: S.t }}
                >
                  Mulai Sekarang
                </Link>
                <Link
                  href="/cek-pesanan"
                  className="text-sm font-medium px-5 py-2.5 rounded-xl transition"
                  style={{ background: "#fff", color: S.t, border: `1px solid ${S.b2}` }}
                >
                  Cek Pesanan
                </Link>
              </div>
              {/* Stats */}
              <div className="flex gap-7 mt-8 pt-7" style={{ borderTop: `1px solid ${S.b}` }}>
                {[{ n: "50K+", l: "Pengguna" }, { n: "200+", l: "Produk" }, { n: "99.9%", l: "Sukses" }].map(s => (
                  <div key={s.l}>
                    <div className="text-xl font-bold" style={{ color: S.t, letterSpacing: "-0.4px" }}>{s.n}</div>
                    <div className="text-xs mt-1" style={{ color: S.s }}>{s.l}</div>
                  </div>
                ))}
              </div>
            </div>
            {/* Mini dashboard card */}
            <div className="rounded-2xl p-5" style={{ background: S.off, border: `1px solid ${S.b}` }}>
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: S.s }}>Transaksi terbaru</span>
                <span
                  className="text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5"
                  style={{ background: S.gbg, color: S.g, border: `1px solid ${S.gb}` }}
                >
                  <span className="w-1.5 h-1.5 rounded-full animate-pulse inline-block" style={{ background: S.g }}></span>
                  Live
                </span>
              </div>
              {[
                { ico: "⚔️", name: "Mobile Legends", sub: "86 Diamonds",   price: "Rp 19.900" },
                { ico: "⚡", name: "Token PLN",       sub: "Rp 100.000",   price: "Rp 100.500" },
                { ico: "🏥", name: "BPJS Kesehatan",  sub: "Januari 2026", price: "Rp 150.000" },
                { ico: "📱", name: "Telkomsel 20GB",  sub: "Paket data",   price: "Rp 65.000" },
              ].map((r, i, arr) => (
                <div
                  key={r.name}
                  className="flex items-center gap-3 py-2.5"
                  style={{ borderBottom: i < arr.length - 1 ? `1px solid ${S.b}` : "none" }}
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-base flex-shrink-0"
                    style={{ background: "#fff", border: `1px solid ${S.b}` }}
                  >{r.ico}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: S.t }}>{r.name}</p>
                    <p className="text-xs" style={{ color: S.s }}>{r.sub}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-semibold" style={{ color: S.t }}>{r.price}</p>
                    <p className="text-xs flex items-center gap-1 justify-end" style={{ color: S.g }}>
                      <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: S.g }}></span>
                      Berhasil
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── FLASH SALE ────────────────────────────────────────────────────── */}
      <FlashSale />

      {/* ── SHORTCUT LAYANAN ──────────────────────────────────────────────── */}
      <section className="bg-white" style={{ borderBottom: `1px solid ${S.b}` }}>
        <div className="max-w-5xl mx-auto px-4 py-7">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {featuredServices.map(svc => (
              <Link
                key={svc.link}
                href={svc.link}
                className="flex items-center gap-3 p-4 rounded-xl border transition-all"
                style={{ background: S.off, borderColor: S.b }}
                onMouseEnter={e => { e.currentTarget.style.background = "#fff"; e.currentTarget.style.borderColor = S.b2; }}
                onMouseLeave={e => { e.currentTarget.style.background = S.off; e.currentTarget.style.borderColor = S.b; }}
              >
                <div
                  className="w-9 h-9 flex items-center justify-center rounded-xl text-lg flex-shrink-0"
                  style={{ background: "#fff", border: `1px solid ${S.b}` }}
                >{svc.ico}</div>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate" style={{ color: S.t }}>{svc.name}</p>
                  <p className="text-xs truncate mt-0.5 hidden sm:block" style={{ color: S.s }}>{svc.sub}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── FILTER CHIPS ──────────────────────────────────────────────────── */}
      <div
        id="produk"
        ref={prodRef}
        className="bg-white sticky top-14 z-40"
        style={{ borderBottom: `1px solid ${S.b}` }}
      >
        <div className="max-w-5xl mx-auto px-4">
          <div
            className="flex gap-2 py-3 overflow-x-auto"
            style={{ scrollbarWidth: "none" }}
          >
            {filters.map(f => (
              <button
                key={f.id}
                onClick={() => handleFilter(f.id)}
                className="flex-shrink-0 text-sm font-medium px-4 py-2 rounded-full transition-all"
                style={
                  activeFilter === f.id
                    ? { background: S.g, color: "#fff", border: `1px solid ${S.g}` }
                    : { background: S.off, color: S.m, border: `1px solid ${S.b}` }
                }
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── PRODUCT SECTIONS ──────────────────────────────────────────────── */}
      <div style={{ background: S.off }}>
        {sections.map(sec => {
          const visible = activeFilter === "all" || activeFilter === sec.id;
          if (!visible) return null;
          return (
            <section
              key={sec.id}
              className="px-4 py-8"
              style={{ borderBottom: `1px solid ${S.b}`, maxWidth: "100%" }}
            >
              <div className="max-w-5xl mx-auto">
                <SectionHeader title={sec.title} showAll />
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {sec.data.map((item, i) => (
                    <ProductCard key={`${sec.id}-${i}`} item={item} />
                  ))}
                </div>
              </div>
            </section>
          );
        })}
      </div>

      {/* ── KENAPA KAYANAPAY ──────────────────────────────────────────────── */}
      <section className="bg-white px-4 py-16" style={{ borderBottom: `1px solid ${S.b}` }}>
        <div className="max-w-5xl mx-auto">
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: S.g }}>
            Kenapa KayanaPay?
          </p>
          <h2 className="text-2xl font-bold mb-3" style={{ color: S.t, letterSpacing: "-0.5px" }}>
            Dirancang untuk semua kalangan
          </h2>
          <p className="text-sm leading-relaxed mb-12 max-w-xl" style={{ color: S.m }}>
            Dari pelajar, mahasiswa, ibu rumah tangga, hingga pelaku bisnis — KayanaPay hadir untuk
            memudahkan transaksi digital sehari-hari.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { ico: "⚡", title: "Proses Instan",     desc: "Setiap transaksi diproses otomatis dalam hitungan detik, 24 jam sehari tanpa hari libur." },
              { ico: "🔒", title: "Aman & Terpercaya", desc: "Sistem keamanan berlapis dengan enkripsi end-to-end. Data dan transaksimu selalu terlindungi." },
              { ico: "💰", title: "Harga Termurah",    desc: "Kami berkomitmen memberikan harga terbaik untuk semua produk, tanpa biaya tersembunyi." },
              { ico: "🎮", title: "Produk Terlengkap", desc: "200+ produk dari game, pulsa, tagihan, hingga voucher entertainment tersedia lengkap." },
              { ico: "🤝", title: "CS Responsif",      desc: "Tim customer service siap membantu via WhatsApp kapanpun kamu butuh bantuan." },
              { ico: "📱", title: "Mudah Digunakan",   desc: "Interface yang bersih dan intuitif — bisa digunakan siapa saja tanpa perlu keahlian khusus." },
            ].map(w => (
              <div
                key={w.title}
                className="p-5 rounded-2xl border transition-all"
                style={{ background: S.off, borderColor: S.b }}
                onMouseEnter={e => { e.currentTarget.style.background = "#fff"; e.currentTarget.style.borderColor = S.b2; }}
                onMouseLeave={e => { e.currentTarget.style.background = S.off; e.currentTarget.style.borderColor = S.b; }}
              >
                <div className="text-2xl mb-4">{w.ico}</div>
                <p className="text-sm font-semibold mb-2" style={{ color: S.t }}>{w.title}</p>
                <p className="text-sm leading-relaxed" style={{ color: S.m }}>{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── STATS BANNER ──────────────────────────────────────────────────── */}
      <section style={{ background: S.t }} className="px-4 py-12">
        <div className="max-w-5xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-px rounded-2xl overflow-hidden"
          style={{ background: "rgba(255,255,255,.08)" }}>
          {[
            { n: "50.000+", l: "Pengguna aktif",          accent: true },
            { n: "200+",    l: "Jenis produk",             accent: false },
            { n: "99.9%",   l: "Tingkat keberhasilan",     accent: false },
            { n: "24/7",    l: "Layanan aktif",            accent: false },
          ].map(s => (
            <div key={s.l} className="p-7 text-center" style={{ background: "rgba(255,255,255,.04)" }}>
              <p className="text-2xl font-bold mb-1.5" style={{ color: s.accent ? S.g : "#fff", letterSpacing: "-0.5px" }}>{s.n}</p>
              <p className="text-xs" style={{ color: "rgba(255,255,255,.45)" }}>{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── FAQ ───────────────────────────────────────────────────────────── */}
      <section className="bg-white px-4 py-16" style={{ borderBottom: `1px solid ${S.b}` }}>
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Left */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: S.g }}>FAQ</p>
            <h2 className="text-2xl font-bold mb-3" style={{ color: S.t, letterSpacing: "-0.5px" }}>Ada pertanyaan?</h2>
            <p className="text-sm leading-relaxed mb-6" style={{ color: S.m }}>
              Temukan jawaban dari pertanyaan yang paling sering ditanyakan. Masih bingung? Hubungi CS kami.
            </p>
            <a
              href="https://wa.me/6285236509562"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block text-sm font-medium px-5 py-2.5 rounded-xl text-white transition"
              style={{ background: S.t }}
            >
              Hubungi CS via WhatsApp →
            </a>
          </div>
          {/* Right */}
          <div className="flex flex-col gap-2">
            {faqs.map((item, i) => (
              <FaqItem key={i} q={item.q} a={item.a} defaultOpen={i === 0} />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ────────────────────────────────────────────────────── */}
      <section className="px-4 py-14" style={{ background: S.g }}>
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-xl font-bold text-white mb-2" style={{ letterSpacing: "-0.4px" }}>
              Mulai transaksi pertamamu sekarang
            </h2>
            <p className="text-sm" style={{ color: "rgba(255,255,255,.75)" }}>
              Daftar gratis, tidak perlu kartu kredit. Proses instan, harga terbaik.
            </p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <Link
              href="/daftar"
              className="text-sm font-medium px-5 py-2.5 rounded-xl transition"
              style={{ background: "#fff", color: S.g }}
            >
              Daftar Gratis
            </Link>
            <Link
              href="/cek-pesanan"
              className="text-sm font-medium px-5 py-2.5 rounded-xl transition"
              style={{ background: "rgba(255,255,255,.15)", color: "#fff", border: "1px solid rgba(255,255,255,.3)" }}
            >
              Cek Pesanan
            </Link>
          </div>
        </div>
      </section>

    </main>
  );
}